//
// Created by doominik on 11.4.2024.
//

#include "Histogram.h"

void Histogram::show(ColorCode color) const {
        for(int i=0;i<data.size();i++){
            for(int j=0;j<data[i];j++)
                PrintUtility::print(color,"*");
        }



}
