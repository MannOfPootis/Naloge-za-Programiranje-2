#include <iostream>

int main() {
    using namespace std::string_literals;
    system(("chcp "s + std::to_string(65001)).c_str());

    std::cout << "Hello, World!" << std::endl;
    return 0;
}
