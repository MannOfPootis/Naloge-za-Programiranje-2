//
// Created by doominik on 11.4.2024.
//

#ifndef NALOGA0602_COLORCODE_H
#define NALOGA0602_COLORCODE_H
enum class ColorCode{
    Red=31,
    Green=32,
    Blue=34,
    Default=39,

};

#endif //NALOGA0602_COLORCODE_H
