//
// Created by doominik on 11.4.2024.
//

#ifndef NALOGA0602_HISTOGRAM_H
#define NALOGA0602_HISTOGRAM_H

#include "Graph.h"
class Histogram:Graph {
public:
    void show(ColorCode color) const;
};


#endif //NALOGA0602_HISTOGRAM_H
