#include <iostream>
#include "PriortyQueue.h"
int main() {
    PriorityQueue<int> bongus;
    bongus.add(1,Priority::High);
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
