//
// Created by doominik on 9.5.2024.
//

#ifndef NALOGA0801_PRIORTYQUEUE_H
#define NALOGA0801_PRIORTYQUEUE_H


#include <vector>
#include <exception>
#include <stdexcept>
#include "Time.h" // Vključite razred Time, če ga potrebujete.

using namespace std;
enum class Priority {
    Low,
    High
};

template <typename T>
class PriorityQueue {
public:
    // Vstavi element v vrsto s prioriteto.
    void add(const T& element, Priority priority) {
        if(priority==Priority::High){
            values.insert(values.begin()+indexNextHigh,element);
            indexNextHigh++;
        } else{
            values.insert(values.begin()+values.size()-1,element);
        }
    }

    // Odstrani element z najvišjo prioriteto in ga vrne.
    T pop() {
        T e = values[0];
        values.erase(0);
        indexNextHigh-=(int)(indexNextHigh>0);//screw you its efficient
        return e;
    }

    // Vrne element z najvišjo prioriteto, ne da bi ga odstranil.
    T getMax() const {
        if(empty())
            throw std::out_of_range("Index out of range for vector access.");
        T e =values[0];
        for( T t:values){
            if(t>e)
                e=t;
        }
        return e;
    }

    // Preveri, ali je vrsta prazna.
    bool empty() const {
        return values.empty();
    }

private:
    vector<T> values;
    int indexNextHigh = 0;



    // Funkcija za iskanje indeksa elementa z najvišjo prioriteto.
    int findMaxIndex() const;
};




#endif //NALOGA0801_PRIORTYQUEUE_H
