#include <iostream>
#include "EventOrganizer.h"
#include "Time.h"
int main() {
    std::cout << "Hello, World!" << std::endl;
    Time teaime=Time(10,1,1000);
    std::cout<<teaime.toString();
    EventAgeGroup a=Adult;
    Location ljublana("šiš 12","šiška","ljubljana","slovenia");
    std::vector<Event> joshpitore;
    EventOrganizer josh("josh",joshpitore,"http://rit/me/boli.si");
    Event žižek(a,&ljublana,DateTime::getCurrentTime(),DateTime::getCurrentTime(),"oče janez ječmen seje",0.01,420);
    josh.addEvent(žižek);
    Event lmao1(a,&ljublana,DateTime::getCurrentTime(),DateTime::getCurrentTime(),"oče janez ječmen seje",0.01,420);
    josh.addEvent(lmao1);


    std::cout<<josh.toString();
    return 0;
}
