//
// Created by doominik on 11.4.2024.
//

#ifndef NALOGA0401_FINANCIALSPONSOR_H
#define NALOGA0401_FINANCIALSPONSOR_H

#include "Sponsor.h"
class financialSponsor:Sponsor {
    float moneyDonated;
    float bankAccount;
public:
    financialSponsor(const std::string &name, unsigned int yearsOfSponsorship, float moneyDonated, float bankAccount);
    std::string toString();
    float calculateScore();
};


#endif //NALOGA0401_FINANCIALSPONSOR_H
