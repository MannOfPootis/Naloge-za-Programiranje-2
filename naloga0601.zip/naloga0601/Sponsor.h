//
// Created by doominik on 11.4.2024.
//

#ifndef NALOGA0401_SPONSOR_H
#define NALOGA0401_SPONSOR_H
#include <string>

 class Sponsor {
 protected:
    std::string name;
    unsigned int yearsOfSponsorship;

public:
    Sponsor(const std::string &name, unsigned int yearsOfSponsorship);


     float calculateScore();

     virtual std::string toString();
};


#endif //NALOGA0401_SPONSOR_H
