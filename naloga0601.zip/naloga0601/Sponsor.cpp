//
// Created by doominik on 11.4.2024.
//

#include "Sponsor.h"
#include "sstream"

Sponsor::Sponsor(const std::string &name, unsigned int yearsOfSponsorship) : name(name),
                                                                             yearsOfSponsorship(yearsOfSponsorship) {}

std::string Sponsor::toString() {
    std::stringstream ss;
    ss<<name<<" "<<yearsOfSponsorship;
    return ss.str();
}
