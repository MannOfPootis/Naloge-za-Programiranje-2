#include <iostream>
#include "CircularLinkedList.h"
int main() {
    CircularLinkedList<int> panis;
    panis.add(1);
    panis.add(2);

    panis.add(3);

    panis.add(4);
    panis.add(5);

    int cum=panis.at(1);
    std::cout<<cum;

    return 0;
}
