//
// Created by doominik on 16.4.2024.
//

#ifndef NALOGA0701_VECTORUTIL1_H
#define NALOGA0701_VECTORUTIL1_H
#include "vector"
template<typename  T>
class VectorUtil1 {
    static void fillDefault(std::vector<T> &vector,int n);
    static void print(std::vector<T>);

};




#endif //NALOGA0701_VECTORUTIL1_H
