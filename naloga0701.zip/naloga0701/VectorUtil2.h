//
// Created by doominik on 16.4.2024.
//

#ifndef NALOGA0701_VECTORUTIL2_H
#define NALOGA0701_VECTORUTIL2_H

#include <iostream>
#include <sstream>
#include "vector"
template<typename T>
void fillDefault(std::vector<T> &vector, int n) {
    for(int i=0;i<n;i++){
        vector.push_back(T());
    }
}
void fillDefault(std::vector<int> &vector, int n) {
    for(int i=0;i<n;i++){
        vector.push_back(1);
    }
}
template<typename T>
void print(std::vector<T> vector)  {
for(int i=0;i<vector.size();i++){
    std::cout<<vector[i];
}
}
template<typename T>
std::vector<float> reverse(std::vector<T> &vector)  {
    for(int i=0;i<vector.size()/2;i++){
        T temp= vector[i];
        vector[i]=vector[vector.size()-i-1];
        vector[vector.size()-i-1]=temp;
    }
    return  vector;

}
template <typename T>
std::vector<int> toInt(std::vector<T> vector){
    std::vector<int> box;
    for(int i =0;i<vector.size();i++){
        std::stringstream ss;
        ss<<vector[i];
        box.push_back(stoi(ss.str()));
    }
    return box;
}
#endif //NALOGA0701_VECTORUTIL2_H
