//
// Created by doominik on 4.4.2024.
//

#include "Bank.h"
#include "sstream"
#include "Date.h"
#include <typeinfo>
#include "SavingsAccount.h"
Bank::Bank()  {}

void Bank::addAccount(Account account) {
    accounts.push_back(account);

}

std::vector<Account> Bank::getAccounts(Person *person) {
    std::vector<Account> box;
    for(int i =0;i<accounts.size();i++){
        if(accounts[i].getOwner()==person){
            box.push_back(accounts[i]);
        }
    }

    return std::vector<Account>();
}

bool Bank::makeDepositOnAccount(double amount, uint number) {
    for(int i =0;i<accounts.size();i++){
        if(accounts[i].getNumber()==number){
            return accounts[i].makeDeposit(amount);
        }
    }
    return false;
}
bool Bank::makeWithdrawlOnAccount(double amount, uint number) {
    for(int i =0;i<accounts.size();i++){
        if(accounts[i].getNumber()==number){
            return accounts[i].makeWithdrawl(amount);
        }
    }
    return false;
}

std::string Bank::toString() {
    std::stringstream ss;

    for(int i =0;i<accounts.size();i++){
        ss<<accounts[i].toString()<<"\n";
    }
    return ss.str();
}

void Bank::applyIneterest() {
    if(Date::getTodysDate().getDay()==1){
        for(int i=0;i<accounts.size();i++){
            if(typeid(accounts[i]).name()=="SavingsAccount")
            {
                SavingsAccount diftype= (SavingsAccount &) accounts[i];
                accounts[i].makeDeposit(diftype.getIntrestRate()*accounts[i].getBalance());
            }
        }
    }

}



