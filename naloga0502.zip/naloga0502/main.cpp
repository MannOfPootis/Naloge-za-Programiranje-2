#include <iostream>
#include "Bank.h"
#include "SavingsAccount.h"
int main() {
    std::cout << "Hello, World!" << std::endl;
    Person joško("jožef" ,"štefan");
    Account zaBiznis(&joško, 1,69.69);
    SavingsAccount zaAvto(&joško,11,9999,0.01);
    Bank nlb;
    nlb.addAccount(zaBiznis);
    nlb.addAccount(zaAvto);
    std::cout<<nlb.toString();




    return 0;
}
